# Module 1 Rebuild: Bootstrap + Inline CSS

This rebuild addresses:
- inline CSS on every page instead of a shared stylesheet
- Bootstrap 5 for formatting and responsive layout
- root-aware routing for nested pages like `bookings/create.php`
- GPS and map selection on booking page
- Bootstrap JS loaded where needed

## Pages
- index.php
- register.php
- login.php
- dashboard.php
- bookings/create.php
- bookings/list.php
- logout.php

## Setup
1. Import `sql/module1_schema.sql`
2. Update `config/env.php`
3. Ensure `uploads/items/` is writable
4. Serve with PHP

## Routing
If the project is inside a subfolder, you may set:
`'base_url' => '/your-folder-name'`

If left blank, the helper auto-detects app root and strips `/bookings` for nested pages.
