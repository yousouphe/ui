<?php
require_once __DIR__ . '/config/functions.php';
require_auth();
require_once __DIR__ . '/config/db.php';
$user = current_user();

$stmt = $pdo->prepare('SELECT COUNT(*) FROM bookings WHERE sender_user_id = ?');
$stmt->execute([$user['id']]);
$totalBookings = (int)$stmt->fetchColumn();

$stmt = $pdo->prepare('SELECT COUNT(*) FROM bookings WHERE sender_user_id = ? AND booking_status = "draft"');
$stmt->execute([$user['id']]);
$draftBookings = (int)$stmt->fetchColumn();

$stmt = $pdo->prepare('SELECT COUNT(*) FROM bookings WHERE sender_user_id = ? AND booking_status = "submitted"');
$stmt->execute([$user['id']]);
$submittedBookings = (int)$stmt->fetchColumn();

$success = flash('success');
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Dashboard</title>
  <base href="<?= e((base_url() === '' ? '/' : base_url() . '/')) ?>">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body{background:linear-gradient(180deg,#09101d,#0d1530 42%,#0b1020);min-height:100vh;color:#eef4ff}
    .glass{background:rgba(17,27,51,.9);border:1px solid rgba(255,255,255,.08);border-radius:1.25rem;box-shadow:0 18px 40px rgba(0,0,0,.22)}
    .navx{background:rgba(8,17,33,.88);border-bottom:1px solid rgba(255,255,255,.08)}
    .text-soft{color:#9fb0d6}
    .metric{font-size:2rem;font-weight:700}
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark navx">
  <div class="container"><a class="navbar-brand fw-bold" href="<?= e(url_path('index.php')) ?>">SwiftDrop</a>
    <div class="navbar-nav ms-auto">
      <a class="nav-link" href="<?= e(url_path('bookings/create.php')) ?>">New Booking</a>
      <a class="nav-link" href="<?= e(url_path('bookings/list.php')) ?>">My Bookings</a>
      <a class="nav-link" href="<?= e(url_path('logout.php')) ?>">Logout</a>
    </div>
  </div>
</nav>
<div class="container py-5">
  <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
  <div class="glass p-4 p-lg-5 mb-4">
    <div class="row g-4 align-items-center">
      <div class="col-lg-7">
        <span class="badge text-bg-primary rounded-pill mb-3">Welcome</span>
        <h1 class="display-6 fw-bold">Hello, <?= e($user['full_name']) ?>.</h1>
        <p class="text-soft">Your dashboard is the control point for Module 1. Create bookings, save drafts, and review your delivery requests.</p>
        <div class="d-flex gap-2 flex-wrap">
          <a class="btn btn-primary" href="<?= e(url_path('bookings/create.php')) ?>">Create New Booking</a>
          <a class="btn btn-outline-light" href="<?= e(url_path('bookings/list.php')) ?>">View My Bookings</a>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="glass p-4">
          <div class="d-flex justify-content-between border-bottom border-secondary-subtle py-2"><span>Email</span><span class="text-soft"><?= e($user['email']) ?></span></div>
          <div class="d-flex justify-content-between border-bottom border-secondary-subtle py-2"><span>Phone</span><span class="text-soft"><?= e($user['phone']) ?></span></div>
          <div class="d-flex justify-content-between py-2"><span>Role</span><span class="text-soft"><?= e(ucfirst($user['role'])) ?></span></div>
        </div>
      </div>
    </div>
  </div>

  <div class="row g-4">
    <div class="col-md-4"><div class="glass p-4"><div class="metric"><?= $totalBookings ?></div><div class="text-soft">Total bookings</div></div></div>
    <div class="col-md-4"><div class="glass p-4"><div class="metric"><?= $draftBookings ?></div><div class="text-soft">Draft bookings</div></div></div>
    <div class="col-md-4"><div class="glass p-4"><div class="metric"><?= $submittedBookings ?></div><div class="text-soft">Submitted bookings</div></div></div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
