<?php require_once __DIR__ . '/config/functions.php'; ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Module 1 - Auth & Booking</title>
  <base href="<?= e((base_url() === '' ? '/' : base_url() . '/')) ?>">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  
  <style>
    body {
      background: linear-gradient(180deg,#09101d,#0d1530 42%,#0b1020);
      min-height: 100vh;
      color: #eef4ff;
    }
    .navbar {
      background: rgba(8,17,33,.88) !important;
      backdrop-filter: blur(10px);
      border-bottom: 1px solid rgba(255,255,255,.08);
    }
    .brand-accent { color:#6ea8fe; }
    .glass {
      background: rgba(17,27,51,.88);
      border: 1px solid rgba(255,255,255,.08);
      box-shadow: 0 18px 40px rgba(0,0,0,.22);
      border-radius: 1.25rem;
    }
    .hero {
      background: rgba(17,27,51,.9);
      border: 1px solid rgba(255,255,255,.08);
      border-radius: 1.5rem;
      box-shadow: 0 18px 40px rgba(0,0,0,.22);
    }
    .text-soft { color:#9fb0d6; }
    .stat-number { font-size:2rem; font-weight:700; }
    .map-wrap { height: 380px; border-radius: 1rem; overflow: hidden; border: 1px solid rgba(255,255,255,.08); }
    .leaflet-container { height:100%; width:100%; }
    .form-control, .form-select {
      background:#0b1430; color:#eef4ff; border-color:rgba(255,255,255,.1);
    }
    .form-control:focus, .form-select:focus {
      background:#0b1430; color:#eef4ff; border-color:#6ea8fe; box-shadow:0 0 0 .2rem rgba(110,168,254,.18);
    }
    .table {
      --bs-table-bg: transparent;
      --bs-table-color: #eef4ff;
      --bs-table-border-color: rgba(255,255,255,.08);
    }
    .btn-outline-light { border-color: rgba(255,255,255,.2); }
    .thumb { width:64px; height:64px; object-fit:cover; border-radius:.75rem; }
    .badge-soft { background: rgba(110,168,254,.18); color:#dce9ff; }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container py-2">
    <a class="navbar-brand fw-bold" href="<?= e(url_path('index.php')) ?>">Swift<span class="brand-accent">Drop</span></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="navMain">
      <ul class="navbar-nav ms-auto gap-lg-2">
        <li class="nav-item"><a class="nav-link" href="<?= e(url_path('index.php')) ?>">Home</a></li>
        <?php if (is_logged_in()): ?>
          <li class="nav-item"><a class="nav-link" href="<?= e(url_path('dashboard.php')) ?>">Dashboard</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= e(url_path('bookings/create.php')) ?>">New Booking</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= e(url_path('bookings/list.php')) ?>">My Bookings</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= e(url_path('logout.php')) ?>">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="<?= e(url_path('register.php')) ?>">Register</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= e(url_path('login.php')) ?>">Login</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<div class="container py-4 py-lg-5">

<section class="hero p-4 p-lg-5 mb-4">
  <div class="row align-items-center g-4">
    <div class="col-lg-7">
      <span class="badge badge-soft rounded-pill px-3 py-2 mb-3">Module 1 Ready</span>
      <h1 class="display-5 fw-bold">Bootstrap-based authentication and booking foundation.</h1>
      <p class="text-soft fs-5">This rebuild uses inline page styling, Bootstrap layout/components, and corrected root-aware routing so nested pages resolve links, redirects, and assets properly.</p>
      <div class="d-flex flex-wrap gap-2">
        <?php if (is_logged_in()): ?>
          <a class="btn btn-primary btn-lg" href="<?= e(url_path('dashboard.php')) ?>">Open Dashboard</a>
          <a class="btn btn-outline-light btn-lg" href="<?= e(url_path('bookings/create.php')) ?>">Create Booking</a>
        <?php else: ?>
          <a class="btn btn-primary btn-lg" href="<?= e(url_path('register.php')) ?>">Create Account</a>
          <a class="btn btn-outline-light btn-lg" href="<?= e(url_path('login.php')) ?>">Sign In</a>
        <?php endif; ?>
      </div>
    </div>
    <div class="col-lg-5">
      <div class="glass p-4">
        <div class="row g-3">
          <div class="col-12"><div class="glass p-3"><div class="stat-number">01</div><div class="text-soft">Sender registration and login</div></div></div>
          <div class="col-12"><div class="glass p-3"><div class="stat-number">02</div><div class="text-soft">Booking form with GPS/map support</div></div></div>
          <div class="col-12"><div class="glass p-3"><div class="stat-number">03</div><div class="text-soft">Booking history for logged-in sender</div></div></div>
        </div>
      </div>
    </div>
  </div>
</section>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>