<?php
require_once __DIR__ . '/config/functions.php';
require_guest();
require_once __DIR__ . '/config/db.php';

$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? AND role = "sender" LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if (!$user || !password_verify($password, $user['password_hash'])) {
        $error = 'Invalid email or password.';
    } elseif ($user['status'] !== 'active') {
        $error = 'Your account is not active.';
    } else {
        $_SESSION['user'] = [
            'id' => (int)$user['id'],
            'full_name' => $user['full_name'],
            'email' => $user['email'],
            'phone' => $user['phone'],
            'role' => $user['role']
        ];
        flash('success', 'Welcome back, ' . $user['full_name'] . '.');
        redirect_to('dashboard.php');
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Login</title>
  <base href="<?= e((base_url() === '' ? '/' : base_url() . '/')) ?>">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body{background:linear-gradient(180deg,#09101d,#0d1530 42%,#0b1020);min-height:100vh;color:#eef4ff}
    .cardx{background:rgba(17,27,51,.92);border:1px solid rgba(255,255,255,.08);border-radius:1.25rem;box-shadow:0 18px 40px rgba(0,0,0,.22)}
    .form-control{background:#0b1430;color:#eef4ff;border-color:rgba(255,255,255,.1)}
    .form-control:focus{background:#0b1430;color:#eef4ff;border-color:#6ea8fe;box-shadow:0 0 0 .2rem rgba(110,168,254,.18)}
    .text-soft{color:#9fb0d6}
  </style>
</head>
<body>
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      <div class="cardx p-4 p-lg-5">
        <div class="row g-4 align-items-center">
          <div class="col-lg-6">
            <h1 class="h2 fw-bold">Sign in</h1>
            <p class="text-soft">Access your bookings and continue where you stopped.</p>
            <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
            <form method="post">
              <div class="mb-3">
                <label class="form-label">Email</label>
                <input class="form-control" type="email" name="email" value="<?= e(old('email')) ?>">
              </div>
              <div class="mb-4">
                <label class="form-label">Password</label>
                <input class="form-control" type="password" name="password">
              </div>
              <div class="d-flex gap-2 flex-wrap">
                <button class="btn btn-primary" type="submit">Login</button>
                <a class="btn btn-outline-light" href="<?= e(url_path('register.php')) ?>">Create account</a>
              </div>
            </form>
          </div>
          <div class="col-lg-6">
            <div class="cardx p-4 h-100">
              <h2 class="h4">Flow in this module</h2>
              <ul class="text-soft mb-0">
                <li class="mb-2">Register sender profile</li>
                <li class="mb-2">Login with session protection</li>
                <li class="mb-2">Create booking with image</li>
                <li class="mb-2">View your own bookings</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="text-center mt-3"><a class="link-light text-decoration-none" href="<?= e(url_path('index.php')) ?>">Back home</a></div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
