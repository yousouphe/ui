<?php
require_once __DIR__ . '/../config/functions.php';
require_role(['sender','admin']);
require_once __DIR__ . '/../config/db.php';

$user = current_user();
$bookingId = (int)($_GET['booking_id'] ?? 0);
if ($bookingId <= 0) exit('Booking ID is required.');

$stmt = $pdo->prepare('SELECT * FROM bookings WHERE id = ? AND sender_user_id = ? LIMIT 1');
$stmt->execute([$bookingId, $user['id']]);
$booking = $stmt->fetch();
if (!$booking) exit('Booking not found.');

if ($booking['pickup_latitude'] === null || $booking['pickup_longitude'] === null) {
    exit('Booking must have pickup coordinates for rider discovery.');
}

$pickupLat = (float)$booking['pickup_latitude'];
$pickupLng = (float)$booking['pickup_longitude'];
$distanceSql = haversine_sql('rp.last_latitude', 'rp.last_longitude', $pickupLat, $pickupLng);

$sql = "SELECT u.id, u.full_name, u.phone, rp.vehicle_type, rp.rating, rp.availability_status,
               rp.last_latitude, rp.last_longitude, $distanceSql AS distance_km
        FROM users u
        INNER JOIN rider_profiles rp ON rp.user_id = u.id
        WHERE u.role = 'rider' AND u.status = 'active' AND rp.availability_status = 'available'
          AND rp.last_latitude IS NOT NULL AND rp.last_longitude IS NOT NULL
        ORDER BY distance_km ASC, rp.rating DESC
        LIMIT 20";
$riders = $pdo->query($sql)->fetchAll();

$success = flash('success');
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Discover Riders</title>
<base href="<?= e((base_url() === '' ? '/' : base_url() . '/')) ?>">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:linear-gradient(180deg,#09101d,#0d1530 42%,#0b1020);min-height:100vh;color:#eef4ff}
.navx{background:rgba(8,17,33,.88);border-bottom:1px solid rgba(255,255,255,.08)}
.cardx{background:rgba(17,27,51,.92);border:1px solid rgba(255,255,255,.08);border-radius:1.25rem;box-shadow:0 18px 40px rgba(0,0,0,.22)}
.text-soft{color:#9fb0d6}
.rider-card{background:#0b1430;border:1px solid rgba(255,255,255,.08);border-radius:1rem}
</style>
</head><body>
<nav class="navbar navbar-expand-lg navbar-dark navx">
  <div class="container">
    <a class="navbar-brand fw-bold" href="<?= e(url_path('dashboard.php')) ?>">Sender Dashboard</a>
    <div class="navbar-nav ms-auto">
      <a class="nav-link" href="<?= e(url_path('logout.php')) ?>">Logout</a>
    </div>
  </div>
</nav>
<div class="container py-5">
  <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
  <div class="cardx p-4 mb-4">
    <div class="row g-3">
      <div class="col-lg-8">
        <h1 class="h3 fw-bold mb-1">Nearby riders for <?= e($booking['booking_code']) ?></h1>
        <div class="text-soft">Pickup: <?= e($booking['pickup_address']) ?> · Delivery: <?= e($booking['delivery_address']) ?></div>
      </div>
      <div class="col-lg-4 text-lg-end">
        <span class="badge text-bg-primary"><?= count($riders) ?> riders found</span>
      </div>
    </div>
  </div>

  <div class="row g-4">
    <?php foreach ($riders as $rider): 
      $suggested = max(1500, round(((float)$rider['distance_km'] * 400) + 1500, -2));
    ?>
    <div class="col-lg-6">
      <div class="cardx p-4 h-100">
        <div class="d-flex justify-content-between align-items-start gap-3">
          <div>
            <h2 class="h5 mb-1"><?= e($rider['full_name']) ?></h2>
            <div class="text-soft small"><?= e(ucfirst($rider['vehicle_type'])) ?> · Rating <?= e(number_format((float)$rider['rating'], 1)) ?></div>
            <div class="text-soft small"><?= e(number_format((float)$rider['distance_km'], 2)) ?> km from pickup</div>
          </div>
          <span class="badge text-bg-success">Available</span>
        </div>
        <div class="rider-card p-3 mt-3">
          <form method="post" action="<?= e(url_path('bookings/send_request.php')) ?>">
            <input type="hidden" name="booking_id" value="<?= (int)$booking['id'] ?>">
            <input type="hidden" name="rider_user_id" value="<?= (int)$rider['id'] ?>">
            <div class="mb-3">
              <label class="form-label">Agreed cost</label>
              <input class="form-control" type="number" min="0" step="0.01" name="proposed_cost" value="<?= e((string)$suggested) ?>">
            </div>
            <button class="btn btn-primary" type="submit">Send Request</button>
          </form>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
</body></html>
