<?php
require_once __DIR__ . '/../config/functions.php';
require_role(['sender','admin']);
require_once __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect_to('dashboard.php');

$user = current_user();
$bookingId = (int)($_POST['booking_id'] ?? 0);
$riderUserId = (int)($_POST['rider_user_id'] ?? 0);
$proposedCost = (float)($_POST['proposed_cost'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM bookings WHERE id = ? AND sender_user_id = ? LIMIT 1');
$stmt->execute([$bookingId, $user['id']]);
$booking = $stmt->fetch();
if (!$booking) exit('Booking not found.');

$stmt = $pdo->prepare('SELECT u.id FROM users u INNER JOIN rider_profiles rp ON rp.user_id = u.id WHERE u.id = ? AND u.role="rider" AND u.status="active" AND rp.availability_status="available" LIMIT 1');
$stmt->execute([$riderUserId]);
$rider = $stmt->fetch();
if (!$rider) exit('Rider is not available.');

$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare('INSERT INTO rider_requests (booking_id, rider_user_id, sender_user_id, proposed_cost, request_status) VALUES (?, ?, ?, ?, "pending")
                           ON DUPLICATE KEY UPDATE proposed_cost = VALUES(proposed_cost), request_status = "pending", rider_response_note = NULL, responded_at = NULL');
    $stmt->execute([$bookingId, $riderUserId, $user['id'], $proposedCost]);

    $stmt = $pdo->prepare('UPDATE bookings SET selected_rider_user_id = ?, agreed_cost = ?, booking_status = "submitted" WHERE id = ?');
    $stmt->execute([$riderUserId, $proposedCost, $bookingId]);

    $pdo->commit();
    flash('success', 'Rider request sent successfully.');
} catch (Throwable $e) {
    $pdo->rollBack();
    exit('Failed to send request: ' . htmlspecialchars($e->getMessage()));
}

redirect_to('bookings/request_status.php?booking_id=' . $bookingId);
