<?php
return [
    'db_host' => '127.0.0.1',
    'db_name' => 'logistics_app',
    'db_user' => 'root',
    'db_pass' => '',
    'base_url' => ''
];
