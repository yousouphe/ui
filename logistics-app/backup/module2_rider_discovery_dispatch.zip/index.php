<?php require_once __DIR__ . '/config/functions.php'; ?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Module 2 - Rider Discovery & Dispatch</title>
<base href="<?= e((base_url() === '' ? '/' : base_url() . '/')) ?>">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:linear-gradient(180deg,#09101d,#0d1530 42%,#0b1020);min-height:100vh;color:#eef4ff}
.hero,.cardx{background:rgba(17,27,51,.92);border:1px solid rgba(255,255,255,.08);border-radius:1.25rem;box-shadow:0 18px 40px rgba(0,0,0,.22)}
.text-soft{color:#9fb0d6}
.navx{background:rgba(8,17,33,.88);border-bottom:1px solid rgba(255,255,255,.08)}
</style>
</head><body>
<nav class="navbar navbar-expand-lg navbar-dark navx">
  <div class="container"><a class="navbar-brand fw-bold" href="<?= e(url_path('index.php')) ?>">SwiftDrop M2</a>
    <div class="navbar-nav ms-auto">
      <?php if (is_logged_in()): ?>
        <?php if ((current_user()['role'] ?? '') === 'rider'): ?>
          <a class="nav-link" href="<?= e(url_path('rider/dashboard.php')) ?>">Rider Dashboard</a>
        <?php else: ?>
          <a class="nav-link" href="<?= e(url_path('dashboard.php')) ?>">Sender Dashboard</a>
          <a class="nav-link" href="<?= e(url_path('bookings/discover.php')) ?>">Discover Riders</a>
        <?php endif; ?>
        <a class="nav-link" href="<?= e(url_path('logout.php')) ?>">Logout</a>
      <?php else: ?>
        <a class="nav-link" href="<?= e(url_path('login.php')) ?>">Login</a>
      <?php endif; ?>
    </div>
  </div>
</nav>
<div class="container py-5">
  <section class="hero p-4 p-lg-5">
    <div class="row g-4 align-items-center">
      <div class="col-lg-8">
        <span class="badge text-bg-primary rounded-pill mb-3">Module 2 Ready</span>
        <h1 class="display-5 fw-bold">Rider discovery and request dispatch.</h1>
        <p class="text-soft fs-5">This module lets a sender discover nearby available riders, propose a cost, send a dispatch request, and lets riders accept or reject from their own dashboard.</p>
        <div class="d-flex gap-2 flex-wrap">
          <a class="btn btn-primary" href="<?= e(url_path('login.php')) ?>">Login</a>
          <a class="btn btn-outline-light" href="<?= e(url_path('bookings/discover.php?booking_id=1')) ?>">Open Demo Discovery</a>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="cardx p-4">
          <h2 class="h5">Demo accounts</h2>
          <div class="text-soft small">
            Sender: sender@example.com / password<br>
            Rider 1: rider1@example.com / password<br>
            Rider 2: rider2@example.com / password<br>
            Rider 3: rider3@example.com / password
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
