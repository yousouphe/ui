<?php
require_once __DIR__ . '/../config/functions.php';
require_role(['rider']);
require_once __DIR__ . '/../config/db.php';

$user = current_user();
$success = flash('success');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lat = ($_POST['latitude'] ?? '') !== '' ? (float)$_POST['latitude'] : null;
    $lng = ($_POST['longitude'] ?? '') !== '' ? (float)$_POST['longitude'] : null;
    $status = in_array($_POST['availability_status'] ?? '', ['available','busy','offline'], true) ? $_POST['availability_status'] : 'available';

    $stmt = $pdo->prepare('UPDATE rider_profiles SET last_latitude = ?, last_longitude = ?, availability_status = ?, last_location_updated_at = NOW() WHERE user_id = ?');
    $stmt->execute([$lat, $lng, $status, $user['id']]);
    flash('success', 'Location updated.');
    redirect_to('rider/update_location.php');
}

$stmt = $pdo->prepare('SELECT * FROM rider_profiles WHERE user_id = ? LIMIT 1');
$stmt->execute([$user['id']]);
$profile = $stmt->fetch();
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Update Rider Location</title>
<base href="<?= e((base_url() === '' ? '/' : base_url() . '/')) ?>">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:linear-gradient(180deg,#09101d,#0d1530 42%,#0b1020);min-height:100vh;color:#eef4ff}
.cardx{background:rgba(17,27,51,.92);border:1px solid rgba(255,255,255,.08);border-radius:1.25rem;box-shadow:0 18px 40px rgba(0,0,0,.22)}
.form-control,.form-select{background:#0b1430;color:#eef4ff;border-color:rgba(255,255,255,.1)}
.form-control:focus,.form-select:focus{background:#0b1430;color:#eef4ff;border-color:#6ea8fe;box-shadow:0 0 0 .2rem rgba(110,168,254,.18)}
</style>
</head><body>
<div class="container py-5">
  <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
  <div class="cardx p-4 p-lg-5">
    <h1 class="h3 fw-bold">Update rider location</h1>
    <p class="text-white-50">Use browser geolocation or type coordinates manually.</p>
    <form method="post">
      <div class="row g-3">
        <div class="col-md-6"><label class="form-label">Latitude</label><input class="form-control" id="latitude" name="latitude" value="<?= e((string)($profile['last_latitude'] ?? '')) ?>"></div>
        <div class="col-md-6"><label class="form-label">Longitude</label><input class="form-control" id="longitude" name="longitude" value="<?= e((string)($profile['last_longitude'] ?? '')) ?>"></div>
        <div class="col-md-6">
          <label class="form-label">Availability</label>
          <select class="form-select" name="availability_status">
            <?php $s = $profile['availability_status'] ?? 'available'; ?>
            <option value="available" <?= $s === 'available' ? 'selected' : '' ?>>Available</option>
            <option value="busy" <?= $s === 'busy' ? 'selected' : '' ?>>Busy</option>
            <option value="offline" <?= $s === 'offline' ? 'selected' : '' ?>>Offline</option>
          </select>
        </div>
        <div class="col-md-6 d-flex align-items-end gap-2 flex-wrap">
          <button class="btn btn-outline-light" type="button" id="use_current_location">Use Current Location</button>
          <button class="btn btn-primary" type="submit">Save</button>
        </div>
      </div>
    </form>
    <a class="btn btn-link text-white mt-3 ps-0" href="<?= e(url_path('rider/dashboard.php')) ?>">Back to rider dashboard</a>
  </div>
</div>
<script>
document.getElementById('use_current_location').addEventListener('click', function () {
  if (!navigator.geolocation) return alert('Geolocation not supported.');
  navigator.geolocation.getCurrentPosition(function(pos) {
    document.getElementById('latitude').value = pos.coords.latitude.toFixed(7);
    document.getElementById('longitude').value = pos.coords.longitude.toFixed(7);
  }, function(err) {
    alert('Unable to fetch current location: ' + err.message);
  }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 });
});
</script>
</body></html>
